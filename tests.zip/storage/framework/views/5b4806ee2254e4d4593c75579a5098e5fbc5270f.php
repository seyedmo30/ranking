<!DOCTYPE html>
<html>
<head>
<title>برترین های ابی</title>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="w3.css">
<link type="text/css" rel="stylesheet" href="main.css" />
<style>


img.star{
	padding-left:3px;padding-top:3px;float:left;
}

@media  screen and (max-width: 800px) {



.active {
    background-color: #4CAF50;
}

div.header{
display:none;

}

.fooot
{
	display:none;
}


.navbar {
    overflow: hidden;
    background-color: #333;
	 position: -webkit-sticky; /* Safari */
    position: sticky;
	top:0;

}

.navbar a {

    float: right;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.subnav {
    float: right;
    overflow: hidden;

}


.active {
    background-color: #4CAF50;
}

.fot {
   position:sticky;
   float:left;
   left: 25px;
   top: 85%;
   border:solid 1px white;
   width: 100px;
   background-color: gray;
   color: black;
   font-weight:bold;
   border-radius:5px;

   text-align: center;
   z-index:6;
}

.subnav .subnavbtn {
    font-size: 16px;
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.navbar a:hover, .subnav:hover .subnavbtn {
    background-color: #4CAF50;
}

.subnav-content {
    display: none;
    position:fixed;
    right: 0;
    background-color: #4CAF50;
    width: 100%;
    z-index: 1;
}

.subnav-content a {
    float: right;
    color: white;
    text-decoration: none;
}

.subnav-content a:hover {
    background-color: #eee;
    color: black;
}

.subnav:hover .subnav-content {
    display: block;
}




  div.sidehidden {
    display: none;
  }

  .head{
  display:none;
  }



  img.lable {
    max-width: 100%;
    height: auto;
    float:left;}

	div.bio , div.all-music{
		width:92%;
	}

  img.bio{
	display:block;
    margin-left: auto;
    margin-right: auto;
	padding:2px;
  }

  div.bio-text{
	direction:rtl;
	margin-top:5px;
  }


	div.music{
		height:135px;
		margin:2px;
		margin-bottom:20px;
		direction:rtl;
		border:3px ridge gray;
		border-radius:10px;
		padding-right:4px;
		padding-top:4px;

	}

  div.music-name{
  float:right;
  font-weight:bold;
  font-size:18px;
  }


  div.music-rate{
		float:left;
		border:solid yellow 4px;
	  padding:2px;
	  margin-right:7px;
	  margin:3px;
	  height:60px;
	  border-radius:5px;

  }
  div.music-comment{
  display:none;
  }

}


@media  screen and (min-width: 801px) {

  div.bio,div.all-music{
			 width:78%;
  }

	div.navbar{
	display:none;
	}


  .fot{
  display:none;
  }




  div.audio{
			float:right;
			display:block;
			margin-right:20px;
  }


  div.music-rate{
  float:right;
  border:solid yellow 4px;
  padding:2px;
  height:57px;
  border-radius:5px;
  }


div.music{
	height:75px;
	margin:5px;
	margin-bottom:20px;
	direction:rtl;
	border:3px ridge gray;
	border-radius:10px;
	padding-right:4px;
	padding-top:8px;

}

  div.music-name{
	float:right;

	margin:10px;
	margin-left:40px;
	font-size:22px;
	font-weight:bold;
  }



  div.music-comment{
		float:left;
		margin:10px;
		margin-left:40px;		font-size:18px;
  }

  div.bio-text{
  padding:20px;margin:5px;direction:rtl;
  }

  img.bio{
	padding:5px;float:left;
  }



.fooot {
   position:sticky;
   clear:both;
   float:left;
   left: 25px;
   top: 85%;
   border:solid 1px white;
   width: 100px;
   background-color: gray;
   color: black;
   font-weight:bold;
   border-radius:5px;

   text-align: center;
   z-index:6;
}


}


</style>

</head>
<body>

<div class="header" style=" direction:ltr;padding:5px;" >
<img class="label" src="mo30.png" alt="mo30.ir" width="200" height=auto>


</div>



<ul class="head " >
  <li class="head"><a class="active" href="index.html"><b>خانه</b></a></li>
  <li class="head"><a href="javascript:void(0)">برترین ها</a></li>
  <li class="head"><a href="signin.html">ورود/ثبت نام</a></li>
</ul>
<div  style="z-index:2;" class="divside; sidehidden">
<ul class="side " style="margin-top:15px;margin-bottom:30px;">
  <li class="side"><a class="active" href="#home">برترین های ابی</a></li>
  <li class="side"><a href="#news">برترین های هایده</a></li>
  <li class="side"><a href="#contact">برترین های داریوش</a></li>
  <li class="side"><a href="#about">ورود/ثبت نظرات</a></li>
</ul>
</div>



<div class="navbar" style="width:100%;z-index:5;">
  <a href="#home">خانه</a>
   <a href="#contact">ورود/ثبت نام</a>
  <div class="subnav">
    <button class="subnavbtn">برترین ها <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="#company">ابی</a>
      <a href="#team">هایده</a>
     <a href="#careers">داریوش</a>
    </div>
  </div>

  </div>


<div class="bio" style="padding:20px;margin:10px;direction:ltr;background-color:#eeeeee;float:left;">
<img  class="bio"  src="image/ebi.jpg" width="200" height="auto">
<div class="bio-text">
ابراهیم حامدی معروف به ابی متولد ۲۹ خرداد ۱۳۲۸ در تهران، خواننده است
دیپلمه ریاضی است، وی بیشتر با نام آقای صدا در ایران شناخته می شود، قبل از انقلاب کارمند فرهنگ و هنر بود، ۴ خواهر و یک برادر داشت که مدت ها پبش برادرش فوت کرد، پدر خیاط و مادرش خانه دار بود
نخستین ترانه مستقل خود را با نام عطش برای فیلمی به همین عنوان ساخته می‌ شود عرضه می کند، دومین ترانه وی چرا چرا نام دارد، اما سومین ترانه ابی که به گفته خودش باعث معروفیت وی می‌ شود ترانه‌ ای است به نام شب با شعر اردلان سرفراز و آهنگ منصور ایران‌ نژاد که برای اولین بار در شوی معروف میخک نقره‌ ای از فریدون فرخزاد پخش می‌ شود

</div>
</div>

<br>


<form action="" type="post" >

<div class="fot">
  ثبت
</div>

<div class="fooot">
  ثبت
</div>



<div  class="all-music" style="overflow:hidden;clear:both;padding:7px;margin:10px;direction:ltr;background-color:#eeeeee;float:left;">

	<div class="music">
	<div class="music-name">
	1 &nbsp
	شانه هایت
	</div>
	<div class="music-rate">
	<span style="font-size:33px;color:gol"><input type="number" style="width:70px;height:40px;" name="rate_shanehayat"></span>&nbsp
	<img class="star" src="image/star.png" alt="rate" width="45" height=auto>

	</div>
	<div class="audio">
	<audio controls>
	  <source src="music/ebi/gol.mp3" type="audio/mpeg">
	</audio>
	</div>
	<div class="music-comment">
	نظرات
	</div>
	</div>





	<div class="music">
	<div class="music-name">
	1 &nbsp
	شانه هایت
	</div>
	<div class="music-rate">
	<span style="font-size:33px;color:gol"><input type="number" style="width:70px;height:40px;" name="rate_shanehayat"></span>&nbsp
	<img class="star" src="image/star.png" alt="rate" width="45" height=auto>

	</div>
	<div class="audio">
	<audio controls>
	  <source src="music/ebi/gol.mp3" type="audio/mpeg">
	</audio>
	</div>
	<div class="music-comment">
	نظرات
	</div>
	</div>






<div class="music">
<div class="music-name">
1 &nbsp&nbsp
شانه هایت
</div>
<div class="music-rate">
<span style="font-size:33px;color:gol">18.42</span>&nbsp
<img class="star" src="image/star.png" alt="rate" width="45" height=auto>

</div>
<div class="audio">
<audio controls>
  <source src="music/ebi/gol.mp3" type="audio/mpeg">
</audio>
</div>
<div class="music-comment">
نظرات
</div>

</div>

<div class="music">
salam

</div>
</div>
<div style="clear:both;">

  </div>
  <div class="foot" style="width:100%;height:80px;background-color:green;float:left;">
	<img src="image/telegram.png" alt="mo30.ir" style="padding-left:30px;padding-top:20px;float:left" width="70" height=auto>
  <img src="image/instagram.png" alt="mo30.ir" style="padding-left:30px;padding-top:20px;float:left" width="70" height=auto>
  <img src="image/email.png" alt="mo30.ir" style="padding-left:20px;padding-top:15px;float:left" width="70" height=auto>

  </div>
</body>
</html>
