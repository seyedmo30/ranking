<?php $__env->startSection('stylemin'); ?>
.signup{
width:75%;float:left;margin:20px;padding:10px;clear:both;
}
<?php $__env->stopSection(); ?>


<?php $__env->startSection('stylemax'); ?>
.signup{
width:90%;float:center;margin:10px;padding:10px;
}
<?php $__env->stopSection(); ?>


<?php $__env->startSection('index'); ?>

<div class="w3-card-2 w3-container signup"  >
Some text to enable scrolling.. Lorem ipsum dolor sit amet, illum definitiones no quo, maluisset concludaturque et eum, altera fabulas ut quo. Atqui causae gloriatur ius te, id agam omnis evertitur eum. Affert laboramus repudiandae nec et. Inciderint efficiantur his ad. Eum no molestiae voluptatibus.
</div>
<br><br><br><br><br>
<div style="max-width:500px;margin-left:auto;margin-right:auto">
  <form method="POST" class="w3-container w3-card-4 w3-light-grey w3-text-green w3-margin" action="<?php echo e(route('register')); ?> " aria-label="<?php echo e(__('Register')); ?>">
      <?php echo csrf_field(); ?>
<h2 class="w3-center">عضویت</h2>
<div class="w3-row w3-section">
  <div class="w3-col" style="width:50px"><i class="w3-xxlarge fa fa-user"></i></div>
    <div class="w3-rest">
      <input id="name" type="text" placeholder="نام" class="w3-input w3-border form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

      <?php if($errors->has('name')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('name')); ?></strong>
          </span>
      <?php endif; ?>
  </div>
</div>


<div class="w3-row w3-section">
  <div class="w3-col" style="width:50px"><i class="w3-xxlarge fa fa-envelope-o"></i></div>
    <div class="w3-rest">
      <input id="email" type="email" placeholder="ایمیل" class="w3-input w3-border form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

      <?php if($errors->has('email')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('email')); ?></strong>
          </span>
      <?php endif; ?>

    </div>
</div>

<div class="w3-row w3-section">
  <div class="w3-col" style="width:50px"><i class="w3-xxlarge fa fa-pencil"></i></div>
    <div class="w3-rest">
      <input id="password" placeholder=" رمز" type="password" class="w3-input w3-border form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

      <?php if($errors->has('password')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password')); ?></strong>
          </span>
      <?php endif; ?>

  </div>
</div>

<div class="w3-row w3-section">
  <div class="w3-col" style="width:50px"><i class="w3-xxlarge fa fa-pencil"></i></div>
    <div class="w3-rest">
      <input class="w3-input w3-border form-control"  id="password-confirm"  name="password_confirmation" required type="password" placeholder="تکرار رمز">
    </div>
</div>
<?php if(session('massage')): ?>
<div style="margin-left:auto;margin-right:auto;">
<?php echo e(session('massage')); ?>

</div>
<?php endif; ?>
<p class="w3-center">
<button class="w3-button w3-section w3-green w3-ripple"> ثبت </button>
</p>

</form>


</div>
<div style="clear:both">
<br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>