<?php $__env->startSection('stylemin'); ?>
.about{
width:75%;float:left;margin:20px;padding:10px;
}
<?php $__env->stopSection(); ?>


<?php $__env->startSection('stylemax'); ?>
.about{
width:90%;float:center;margin:10px;padding:10px;
}
<?php $__env->stopSection(); ?>


<?php $__env->startSection('index'); ?>

<div class="w3-card-2 w3-container about"  >
برای ورود در سایت ،ایمیل و رمز خود را وارد کنید
<br>
در صورتی که هنوز در سایت ثبت نام نکرده اید گزینه ی ثبت نام را بزنید
<br>
<br>
ثبت نام برای شما هیچ هزینه ای ندارد


</div>
<div style="margin-left:auto;margin-right:auto;width:100px"><a style="" href="/register">
<button   class="w3-button w3-section w3-green w3-ripple"> ثبت نام </button>
</div>
</a>
<div style="max-width:500px;margin-left:auto;margin-right:auto">
<form action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>" method="post" class="w3-container w3-card-4 w3-light-grey w3-text-green w3-margin">
<?php echo csrf_field(); ?>
<h2 class="w3-center">عضویت</h2>
<div class="w3-row w3-section">
  <div class="w3-col" style="width:50px"><i class="w3-xxlarge fa fa-envelope-o"></i></div>
    <div class="w3-rest">
      <input id="email" type="email" placeholder="ایمیل" class=" w3-input w3-border form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
      <?php if($errors->has('email')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('email')); ?></strong>
          </span>
      <?php endif; ?>

    </div>
</div>

<div class="w3-row w3-section">
  <div class="w3-col" style="width:50px"><i class="w3-xxlarge fa fa-pencil"></i></div>
    <div class="w3-rest">
      <input id="password" type="password" class="w3-input w3-border form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required   placeholder="رمز">

      <?php if($errors->has('password')): ?>
          <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password')); ?></strong>
          </span>
      <?php endif; ?>
      <br>مرا به یاد داشته باش
      <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

<div style="float:left">
      <a  href="<?php echo e(route('password.request')); ?>">
      رمز خود را فراموش کردم
      </a>
</div>
    </div>
</div>

<?php if(session('massage')): ?>
<div style="margin-left:auto;margin-right:auto;">
<?php echo e(session('massage')); ?>

</div>
<?php endif; ?>

<p class="w3-center">
<button style="margin-right:15px;"class="w3-button w3-section w3-green w3-ripple"> ورود </button>
</p>

</form>
</div>
<div style="clear:both">
<br>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>